import React from 'react'
import './App.css';
import Example from './Components/Example'

function App() {
  return (
    <Example />
  );
}

export default App;
